//
//  CollectionViewCell.swift
//  Bazzar
//
//  Created by kireeti on 16/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import Kingfisher

class CollectionViewCell: UICollectionViewCell {
  
    @IBOutlet var priceLbl: UILabel!
    
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var img: UIImageView!
    
    var itemData : ItemData? {
        didSet{
            if let itemData = itemData {
                
                self.nameLbl.text = itemData.name
                self.priceLbl.text = "$\(itemData.price!).00"
                let index = 3
                if index >= 0 && index < itemData.custom_attributes.count {
                    if let thumbnail = itemData.custom_attributes[index].value {
                        self.img.kf.setImage(with: URL(string: thumbnail), placeholder: nil, options: [.transition(ImageTransition.fade(1)), .scaleFactor(1.0)], progressBlock: { (receivedSize, totalSize) in
                        }, completionHandler: { (image: Image?, error: NSError?, cacheType, urlImage: URL?) in
                        })
                    }
                } else{ return }
    }
        }
    }
    
}

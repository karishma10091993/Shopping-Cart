//
//  Constant.swift
//  Bazzar
//
//  Created by kireeti on 16/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation

class Constant {
    
    static let server = "https://punjabstore.co.in"
    static let mediaPath = server + "/magento2.2/pub/media/catalog/product"
    static let productListing = server + "/magento2.2/rest/V1/products?"
    
}


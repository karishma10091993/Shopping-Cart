//
//  Model.swift
//  Bazzar
//
//  Created by kireeti on 16/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation

class ItemData {
    
  
    
    var name : String?
    var price : Int?
    var created_at: String?
    var custom_attributes = [CustomAttribute]()
 
    init(dict: [String: Any]) {
        self.name = dict["name"] as? String
        self.price = dict["price"] as? Int
      
        self.created_at = dict["created_at"] as? String
        let customAttr =  dict["custom_attributes"] as! [[String : Any]]
        for item  in customAttr{
            let customData = CustomAttribute.init(dict: item)
            self.custom_attributes.append(customData)
        }
    }
  
    
}


class CustomAttribute {
    
    var attribute_code : String?
    var value : String?
    init(dict : [String : Any]) {
        self.attribute_code = dict["attribute_code"] as? String
        self.value = dict["value"] as? String
        if attribute_code == "thumbnail" && self.value != nil{
        self.value = Constant.mediaPath + self.value!
        }
    }

}

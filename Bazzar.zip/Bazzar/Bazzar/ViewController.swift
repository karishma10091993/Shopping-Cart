//
//  ViewController.swift
//  Bazzar
//
//  Created by kireeti on 16/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import Kingfisher
import CFNetwork

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet var collectionView: UICollectionView!
    var page = 0
    var waiting: Bool? = false
    var productArray  = [ItemData]()
    override func viewDidLoad() {
        super.viewDidLoad()
       
       parseJson()
    }

    func parseJson(){
        
       let  urlStr = "https://punjabstore.co.in/magento2.2/rest/V1/products?searchCriteria[filter_groups][0][filters][0][field]=category_id&searchCriteria[filter_groups][0][filters][0][value]=2&searchCriteria[filter_groups][1][filters][0][field]=visibility&searchCriteria[filter_groups][1][filters][0][value]=4&searchCriteria[currentPage]=0&searchCriteria[pageSize]=42"
        let url = URL.init(string: urlStr)
        let urlReq = URLRequest.init(url: url!)
        URLSession.shared.dataTask(with: urlReq) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as!  NSDictionary
                let items = json["items"] as! [[String: Any]]
                for prod in items {
                    let a =  ItemData.init(dict: prod)
                    self.productArray.append(a)
                }
            print("self.productArray---->",self.productArray)
                
                DispatchQueue.main.async {
                     self.waiting = false
                    self.collectionView.reloadData()
                }
            }catch{
                print(error.localizedDescription)
            }
            
            
        }.resume()
        
        
        
        
        
    }
    
    //Collectionview Data
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return self.productArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.itemData = self.productArray[indexPath.row]
        
        return cell

    }
    

    
    
    
    
    
}

